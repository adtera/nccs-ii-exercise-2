In order to run the evaluation please run:

python io_stream_energies.py trajectory.txt